package lab.phb.oopuas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OopUasApplicationTests {

	@Test
	void contextLoads() {
	}

}
